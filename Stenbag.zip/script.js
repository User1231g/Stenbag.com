const players = [
  { name: "Yarik2020", score: 3000 },
  { name: "MaxPlay", score: 2500 },
  { name: "Admin4ik", score: 2100 },
];
const list = document.getElementById("topPlayers");
players.forEach(p => {
  const li = document.createElement("li");
  li.textContent = `${p.name} — ${p.score} очок`;
  list.appendChild(li);
});
